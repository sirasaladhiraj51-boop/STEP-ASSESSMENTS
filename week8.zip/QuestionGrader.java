import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

abstract class Question {
    String questionText;
    String correctAnswer;
    String studentAnswer;
    double points;

    Question(String questionText, String correctAnswer,
             String studentAnswer, double points) {
        this.questionText = questionText;
        this.correctAnswer = correctAnswer;
        this.studentAnswer = studentAnswer;
        this.points = points;
    }

    abstract double evaluate();

    abstract String getType();
}

class MCQ extends Question {
    MCQ(String q, String c, String s, double p) {
        super(q, c, s, p);
    }

    double evaluate() {
        return studentAnswer.equalsIgnoreCase(correctAnswer)
                ? points : 0;
    }

    String getType() {
        return "MCQ";
    }
}

class TF extends Question {
    TF(String q, String c, String s, double p) {
        super(q, c, s, p);
    }

    double evaluate() {
        return studentAnswer.equalsIgnoreCase(correctAnswer)
                ? points : 0;
    }

    String getType() {
        return "TF";
    }
}

class Essay extends Question {
    Essay(String q, String c, String s, double p) {
        super(q, c, s, p);
    }

    double evaluate() {
        String[] keywords = correctAnswer.split(",");
        String answer = studentAnswer.toLowerCase();
        int matches = 0;

        for (String keyword : keywords) {
            if (answer.contains(keyword.trim().toLowerCase())) {
                matches++;
            }
        }

        if (matches >= 2) {
            return points * 0.75;
        } else if (matches == 1) {
            return points * 0.50;
        }

        return 0;
    }

    String getType() {
        return "ESSAY";
    }
}

public class QuestionGrader {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = Integer.parseInt(sc.nextLine().trim());

        Question[] questions = new Question[n];

        Pattern pattern = Pattern.compile("\"([^\"]*)\"|(\\S+)");

        for (int i = 0; i < n; i++) {
            String line = sc.nextLine().trim();
            Matcher matcher = pattern.matcher(line);

            String[] tokens = new String[5];
            int count = 0;

            while (matcher.find()) {
                tokens[count++] = matcher.group(1) != null
                        ? matcher.group(1) : matcher.group(2);
            }

            String type = tokens[0].toUpperCase();
            String q = tokens[1];
            String correct = tokens[2];
            String student = tokens[3];
            double points = Double.parseDouble(tokens[4]);

            switch (type) {
                case "MCQ":
                    questions[i] = new MCQ(q, correct, student, points);
                    break;
                case "TF":
                    questions[i] = new TF(q, correct, student, points);
                    break;
                case "ESSAY":
                    questions[i] = new Essay(q, correct, student, points);
                    break;
            }
        }

        double total = 0;

        for (Question q : questions) {
            double score = q.evaluate();
            System.out.printf("%s: %.2f%n", q.getType(), score);
            total += score;
        }

        System.out.printf("Total Score: %.2f%n", total);
        sc.close();
    }
}
