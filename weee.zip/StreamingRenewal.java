import java.util.Scanner;
import java.time.LocalDate;

abstract class Subscription {
    String name;
    LocalDate startDate;

    Subscription(String name, String startDate) {
        this.name = name;
        this.startDate = LocalDate.parse(startDate);
    }

    abstract int getValidityDays();

    LocalDate getRenewalDate() {
        return startDate.plusDays(getValidityDays());
    }
}

class Basic extends Subscription {
    Basic(String name, String date) {
        super(name, date);
    }

    int getValidityDays() {
        return 30;
    }
}

class Standard extends Subscription {
    Standard(String name, String date) {
        super(name, date);
    }

    int getValidityDays() {
        return 90;
    }
}

class Premium extends Subscription {
    Premium(String name, String date) {
        super(name, date);
    }

    int getValidityDays() {
        return 365;
    }
}

public class StreamingRenewal {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        Subscription[] subscriptions = new Subscription[n];

        for (int i = 0; i < n; i++) {
            String type = sc.next().toUpperCase();
            String name = sc.next();
            String date = sc.next();

            switch (type) {
                case "BASIC":
                    subscriptions[i] = new Basic(name, date);
                    break;
                case "STANDARD":
                    subscriptions[i] = new Standard(name, date);
                    break;
                case "PREMIUM":
                    subscriptions[i] = new Premium(name, date);
                    break;
            }
        }

        for (Subscription s : subscriptions) {
            System.out.println(s.name + ": " + s.getRenewalDate());
        }

        sc.close();
    }
}