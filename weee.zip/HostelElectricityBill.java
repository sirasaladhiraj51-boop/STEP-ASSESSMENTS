import java.util.Scanner;

abstract class Room {
    int units;

    Room(int units) {
        this.units = units;
    }

    abstract double calculateBill();

    String getType() {
        return getClass().getSimpleName().toUpperCase();
    }
}

class Single extends Room {
    Single(int units) {
        super(units);
    }

    double calculateBill() {
        return units * 8.0;
    }
}

class Shared extends Room {
    int occupants;

    Shared(int units, int occupants) {
        super(units);
        this.occupants = occupants;
    }

    double calculateBill() {
        return (units * 6.0) / occupants;
    }
}

class AC extends Room {
    AC(int units) {
        super(units);
    }

    double calculateBill() {
        return units * 10.0 + 200;
    }
}

public class HostelElectricityBill {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int n = sc.nextInt();
        Room[] rooms = new Room[n];
        double total = 0;

        for (int i = 0; i < n; i++) {
            String type = sc.next().toUpperCase();
            int units = sc.nextInt();

            switch (type) {
                case "SINGLE":
                    rooms[i] = new Single(units);
                    break;
                case "SHARED":
                    int occupants = sc.nextInt();
                    rooms[i] = new Shared(units, occupants);
                    break;
                case "AC":
                    rooms[i] = new AC(units);
                    break;
            }
        }

        for (Room room : rooms) {
            double bill = room.calculateBill();
            System.out.printf("%s: %.2f%n",
                    room.getType(), bill);
            total += bill;
        }

        System.out.printf("Total: %.2f%n", total);
        sc.close();
    }
}
